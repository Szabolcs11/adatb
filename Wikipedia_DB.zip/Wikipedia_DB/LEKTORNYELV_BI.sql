--------------------------------------------------------
--  DDL for Trigger LEKTORNYELV_BI
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE TRIGGER "SYSTEM"."LEKTORNYELV_BI" 
BEFORE INSERT ON LEKTORNYELV
FOR EACH ROW
 WHEN (NEW.ID IS NULL) BEGIN
  :NEW.ID := LEKTORNYELV_SEQ.NEXTVAL;
END;

/
ALTER TRIGGER "SYSTEM"."LEKTORNYELV_BI" ENABLE;
