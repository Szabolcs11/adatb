--------------------------------------------------------
--  DDL for Trigger TRG_SZOCIKK_UPDATE
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE TRIGGER "SYSTEM"."TRG_SZOCIKK_UPDATE" 
AFTER UPDATE ON SZOCIKK
FOR EACH ROW
BEGIN
    INSERT INTO SZOCIKK_UPDATED (id, SzocikkID, UjTartalom, ModositasDatum)
    VALUES (SZOCIKK_UPDATED_SEQ.NEXTVAL, :NEW.id, :NEW.Tartalom, SYSDATE);
END;



/
ALTER TRIGGER "SYSTEM"."TRG_SZOCIKK_UPDATE" ENABLE;
