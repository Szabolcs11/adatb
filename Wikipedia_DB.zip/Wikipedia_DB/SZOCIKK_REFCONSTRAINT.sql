--------------------------------------------------------
--  Ref Constraints for Table SZOCIKK
--------------------------------------------------------

  ALTER TABLE "SYSTEM"."SZOCIKK" ADD CONSTRAINT "FK_SZOCIKK_SZERZO" FOREIGN KEY ("SZERZO_ID")
	  REFERENCES "SYSTEM"."FELHASZNALO" ("ID") ON DELETE CASCADE ENABLE;
