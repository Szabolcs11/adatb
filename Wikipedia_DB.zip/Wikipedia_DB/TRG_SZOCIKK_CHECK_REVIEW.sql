--------------------------------------------------------
--  DDL for Trigger TRG_SZOCIKK_CHECK_REVIEW
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE TRIGGER "SYSTEM"."TRG_SZOCIKK_CHECK_REVIEW" 

BEFORE UPDATE ON SZOCIKK

FOR EACH ROW

BEGIN

    IF :OLD.STATUSZ != 'Lektorálásra vár' THEN

        :NEW.STATUSZ := 'Lektorálásra vár';

END IF;

END;



/
ALTER TRIGGER "SYSTEM"."TRG_SZOCIKK_CHECK_REVIEW" ENABLE;
