--------------------------------------------------------
--  DDL for Procedure LEKTOROK_TOBB_NYELVEN_PROC
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."LEKTOROK_TOBB_NYELVEN_PROC" (p_result OUT SYS_REFCURSOR) AS
BEGIN
    OPEN p_result FOR
    SELECT l.id, l.tudomanyos_fokozat, COUNT(*) AS nyelvdb
    FROM Lektor l
    JOIN LektorNyelv ln ON l.id = ln.lektor_id
    GROUP BY l.id, l.tudomanyos_fokozat
    HAVING COUNT(*) >= 2;
END;

/
