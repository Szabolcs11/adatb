--------------------------------------------------------
--  Constraints for Table LOGMNR_PARAMETER$
--------------------------------------------------------

  ALTER TABLE "SYSTEM"."LOGMNR_PARAMETER$" MODIFY ("SESSION#" NOT NULL ENABLE);
  ALTER TABLE "SYSTEM"."LOGMNR_PARAMETER$" MODIFY ("NAME" NOT NULL ENABLE);
