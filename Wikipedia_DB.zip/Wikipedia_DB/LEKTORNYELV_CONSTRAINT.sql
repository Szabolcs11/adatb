--------------------------------------------------------
--  Constraints for Table LEKTORNYELV
--------------------------------------------------------

  ALTER TABLE "SYSTEM"."LEKTORNYELV" MODIFY ("LEKTOR_ID" NOT NULL ENABLE);
