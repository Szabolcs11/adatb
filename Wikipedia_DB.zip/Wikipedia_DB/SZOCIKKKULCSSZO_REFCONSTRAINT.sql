--------------------------------------------------------
--  Ref Constraints for Table SZOCIKKKULCSSZO
--------------------------------------------------------

  ALTER TABLE "SYSTEM"."SZOCIKKKULCSSZO" ADD CONSTRAINT "FK_SZOCIKK_KULCSSZO_SZOCIKK" FOREIGN KEY ("SZOCIKK_ID")
	  REFERENCES "SYSTEM"."SZOCIKK" ("ID") ON DELETE CASCADE ENABLE;
