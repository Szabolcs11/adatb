--------------------------------------------------------
--  DDL for Sequence SZOCIKK_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "SYSTEM"."SZOCIKK_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 35 NOCACHE  NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
