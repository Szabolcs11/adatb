--------------------------------------------------------
--  DDL for Sequence LEKTORNYELV_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "SYSTEM"."LEKTORNYELV_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 18 NOCACHE  NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
