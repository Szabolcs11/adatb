--------------------------------------------------------
--  DDL for Sequence FELHASZNALO_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "SYSTEM"."FELHASZNALO_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 7 NOCACHE  NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
