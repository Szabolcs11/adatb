--------------------------------------------------------
--  Constraints for Table LOGSTDBY$EVENTS
--------------------------------------------------------

  ALTER TABLE "SYSTEM"."LOGSTDBY$EVENTS" MODIFY ("EVENT_TIME" NOT NULL ENABLE);
