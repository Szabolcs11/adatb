--------------------------------------------------------
--  DDL for Index LOGMNRT_MDDL$_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "SYSTEM"."LOGMNRT_MDDL$_PK" ON "SYSTEM"."LOGMNRT_MDDL$" ("SOURCE_OBJ#", "SOURCE_ROWID") ;
