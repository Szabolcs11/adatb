--------------------------------------------------------
--  Ref Constraints for Table SZOCIKKLEKTOR
--------------------------------------------------------

  ALTER TABLE "SYSTEM"."SZOCIKKLEKTOR" ADD CONSTRAINT "FK_SZOCIKK_LEKTOR_SZOCIKK" FOREIGN KEY ("SZOCIKK_ID")
	  REFERENCES "SYSTEM"."SZOCIKK" ("ID") ON DELETE CASCADE ENABLE;
