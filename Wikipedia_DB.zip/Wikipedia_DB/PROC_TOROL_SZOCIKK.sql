--------------------------------------------------------
--  DDL for Procedure PROC_TOROL_SZOCIKK
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."PROC_TOROL_SZOCIKK" (
    p_id IN NUMBER
)
AS
BEGIN
    DELETE FROM SZOCIKK
    WHERE ID = p_id;

    IF SQL%ROWCOUNT = 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Nincs ilyen ID a SZOCIKK táblában.');
    END IF;
END;



/
