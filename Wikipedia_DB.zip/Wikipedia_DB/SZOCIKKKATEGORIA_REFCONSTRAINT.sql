--------------------------------------------------------
--  Ref Constraints for Table SZOCIKKKATEGORIA
--------------------------------------------------------

  ALTER TABLE "SYSTEM"."SZOCIKKKATEGORIA" ADD CONSTRAINT "FK_SZOCIKK_KATEGORIA_SZOCIKK" FOREIGN KEY ("SZOCIKK_ID")
	  REFERENCES "SYSTEM"."SZOCIKK" ("ID") ON DELETE CASCADE ENABLE;
