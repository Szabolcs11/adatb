--------------------------------------------------------
--  DDL for Sequence KULCSSZO_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "SYSTEM"."KULCSSZO_SEQ"  MINVALUE 10 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 50 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
