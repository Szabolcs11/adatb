--------------------------------------------------------
--  Ref Constraints for Table TEMAKOR
--------------------------------------------------------

  ALTER TABLE "SYSTEM"."TEMAKOR" ADD CONSTRAINT "FK_TEMAKOR_SZULO" FOREIGN KEY ("SZULO_TEMA_ID")
	  REFERENCES "SYSTEM"."TEMAKOR" ("ID") ON DELETE CASCADE ENABLE;
