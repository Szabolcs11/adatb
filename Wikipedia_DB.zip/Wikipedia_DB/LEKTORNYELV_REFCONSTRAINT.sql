--------------------------------------------------------
--  Ref Constraints for Table LEKTORNYELV
--------------------------------------------------------

  ALTER TABLE "SYSTEM"."LEKTORNYELV" ADD CONSTRAINT "FK_LEKTOR_NYELV_LEKTOR" FOREIGN KEY ("LEKTOR_ID")
	  REFERENCES "SYSTEM"."LEKTOR" ("ID") ON DELETE CASCADE ENABLE;
