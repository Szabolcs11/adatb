--------------------------------------------------------
--  DDL for Sequence HIBA_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "SYSTEM"."HIBA_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 37 NOCACHE  NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
