--------------------------------------------------------
--  DDL for Procedure BEJELENT_HIBA
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."BEJELENT_HIBA" (
    p_szoveg IN VARCHAR2,
    p_statusz IN VARCHAR2,
    p_felhasznalo_id IN NUMBER,
    p_szocikk_id IN NUMBER
)
AS
BEGIN
    INSERT INTO HIBA (ID, SZOVEG, STATUSZ, FELHASZNALO_ID, SZOCIKK_ID)
    VALUES (HIBA_SEQ.NEXTVAL, p_szoveg, p_statusz, p_felhasznalo_id, p_szocikk_id);
END BEJELENT_HIBA;

/
