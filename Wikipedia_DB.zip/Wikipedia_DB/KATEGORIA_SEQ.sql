--------------------------------------------------------
--  DDL for Sequence KATEGORIA_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "SYSTEM"."KATEGORIA_SEQ"  MINVALUE 30 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 141 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
